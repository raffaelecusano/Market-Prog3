
// $(document).ready(function(){
//
//     $(".is-4").each(function (){
//         var categoria = $(".cardTitle",this).text();
//         if( categoria.localeCompare("Fai da te casa")==0 ){
//             $("img",this).attr("src","img/hand-holding-construction-tools.jpg");
//             $(".desc",this).text("Tutto quello che ti serve per abbellire e decorare la tua casa");
//         }
//         else if( categoria.localeCompare("Giardinaggio")==0  ){
//             $("img",this).attr("src","img/garden-worker.jpg");
//             $(".desc",this).text("Scopri la nostra selezione in vasi e accessori per piante, attrezzature per l'irrigazione, prodotti fitosanitari e pesticidi, utensili manuali, accessori e abbigliamento, letti rialzati per giardino e strutture di supporto e tanto altro.");
//         }
//     })
//
// });


$(window).on('click', '.goButton', function(){
    let currDIV = $(this).parent().get(0); //ottengo il div di appartenenza del bottone
    let categoria = $(currDIV).children(".cardTitle").text(); //e il nome della categoria dal titolo
    window.location.href="/products/"+categoria+""; //in base a questo richiedo la pagina corrispondente
});
