package com.market.Factory;

import com.market.Strategy.CreditPay;
import com.market.Strategy.DebitPay;
import com.market.Strategy.Pagamento;
import com.market.Strategy.Paypal;

import java.util.HashMap;
import java.util.Map;

public class paymentFactory {
    Map<String, Pagamento> payments;
    private static paymentFactory instance;

    private paymentFactory(){
        payments = new HashMap<>();
        payments.put("credito", new CreditPay());
        payments.put("debito", new DebitPay());
        payments.put("paypal", new Paypal());

    }

    public static paymentFactory getInstance(){
        if (instance == null)
            instance = new paymentFactory();
        return instance;
    }

    public Pagamento getAction(String pagamento)  {

       return payments.get(pagamento);
    }
}

