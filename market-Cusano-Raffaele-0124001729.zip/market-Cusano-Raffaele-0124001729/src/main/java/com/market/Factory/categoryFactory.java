package com.market.Factory;

import java.util.HashMap;
import java.util.Map;

public class categoryFactory {

    Map<String, Integer> cat;
    private static categoryFactory instance;

    private categoryFactory(){
        cat = new HashMap<>();
        cat.put("ABBIGLIAMENTO MAGLIE UOMO", 1);
        cat.put("ACCESSORI SCARPE DONNA", 2);
        cat.put("NATALE ALBERI", 3);
        cat.put("TECNOLOGIA TV", 5);
        cat.put("ABBIGLIAMENTO MAGLIE DONNA", 6);
        cat.put("ACCESSORI SCARPE UOMO", 7);
        cat.put("NATALE LUCI", 8);
        cat.put("TECNOLOGIA CELLULARI", 9);

    }

    public static categoryFactory getInstance(){
        if (instance == null)
            instance = new categoryFactory();
        return instance;
    }

    public Integer getAction(String cate)  {

        return cat.get(cate);
    }

}
