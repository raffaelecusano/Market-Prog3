package com.market.model;


public class Cliente implements TypeUser{

   // private Carrello carrello;
    //private ArrayList<Offer> offerte;
   // private ArrayList<Integer> offerInCart; //tiene conto delle offerte che si trovano nel carrello (sono memorizzati gli ID offerte)

    public Cliente(String username) {
       /* carrello = new Carrello();
        offerte = getDAO().getOfferByUsr(username);
        offerInCart = new ArrayList<>();

        */
    }

    @Override
    public String doAct() { return "Sono un cliente"; }
/*
    @Override
    public void insProd(ProdItem prodotto){
        System.out.println("Non sei autorizzato a eseguire questa operazione");
    }

    @Override
    public void editProd(ProdItem prodotto){ System.out.println("Non sei autorizzato a eseguire questa operazione"); }

    @Override
    public int addToCart(Integer id){
        ProdItem prod = null;
        try {
            prod = getDAO().getProduct(id);
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        if( prod.getScorte()>0 ){
            carrello.addItem(prod);
            return 1; //ritorno 1 per indicare che l'operazione è stata eseguita con successo
        }
        else
            return 0; //ritorno 0 per indicare che non è stato possibile inserire il prodotto nel carrello poichè esaurito
    }

    @Override
    public int getCartItemN(){
        return carrello.getNprod();
    }

    @Override
    public List<ProdPreview> getCartItemView(){
        return carrello.getProdPreview();
    }

    @Override
    public int removeCartItem(Integer id){
        return carrello.removeItem(id);
    }

    @Override
    public int pay(PaymentStrategy paymentMethod){
        if(!offerInCart.isEmpty()){ //se c'è prodotto in offerta nel carrello
            for(Integer off : offerInCart){ //scorrendo i vari ID delle offerte nel carrello
                //vado a rimuovere dalle offerte salvate per il cliente sia nell'arraylist
                offerte.removeIf(offer -> offer.getIDoffer().equals(off));
                //sia sul DB
                getDAO().removeOffer(off);
            }
            offerInCart.clear(); //quindi dopo l'acquisto non ci sono piu' offerte nel carrello
        }
        return carrello.pay(paymentMethod);
    }

    @Override
    public AdminPanel getAdminPanel(){
        System.out.println("Non sei amministratore");
        return null;
    }

    @Override
    public ArrayList<Offer> getMyOffer(){
        return offerte;
    }

    @Override
    public int addOfferToCart(Integer idOffer, Integer id, Double discountPrice){
        offerInCart.add(idOffer);
        ProdItem prod = null;
        try {
            prod = getDAO().getProduct(id);
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        prod.changePrice(discountPrice);
        if( prod.getScorte()>0 ){
            carrello.addItem(prod);
            return 1; //ritorno 1 per indicare che l'operazione è stata eseguita con successo
        }
        else
            return 0; //ritorno 0 per indicare che non è stato possibile inserire il prodotto nel carrello poichè esaurito
    }

    @Override
    public int deleteProd(Integer idProd){
        System.out.println("Operazione non consentita");
        return -1;
    }

    @Override
    public int checkNewOffer(){
        if(offerte.isEmpty()) //se non ci sono offerte per il cliente che ha accesso
            return 0; //ritorno 0
        else //altrimenti
            return 1; //ritorno 1
    }

 */
}
