package com.market.model;

public class Acquisti {
    private Integer id_ricevuta;
    private Integer id_prodotti;
    private Integer qnt;

    public Integer getId_ricevuta() {
        return id_ricevuta;
    }

    public void setId_ricevuta(Integer id_ricevuta) {
        this.id_ricevuta = id_ricevuta;
    }

    public Integer getId_prodotti() {
        return id_prodotti;
    }

    public void setId_prodotti(Integer id_prodotti) {
        this.id_prodotti = id_prodotti;
    }

    public Integer getQnt() {
        return qnt;
    }

    public void setQnt(Integer qnt) {
        this.qnt = qnt;
    }
}
