package com.market.model;

public class Categorie {

    private Integer id_cat;
    private String nome_cat;
    private String nome_sott;

    public Integer getId_cat() {
        return id_cat;
    }

    public void setId_cat(Integer id_cat) {
        this.id_cat = id_cat;
    }

    public String getNome_cat() {
        return nome_cat;
    }

    public void setNome_cat(String nome_cat) {
        this.nome_cat = nome_cat;
    }

    public String getNome_sott() {
        return nome_sott;
    }

    public void setNome_sott(String nome_sott) {
        this.nome_sott = nome_sott;
    }




}
