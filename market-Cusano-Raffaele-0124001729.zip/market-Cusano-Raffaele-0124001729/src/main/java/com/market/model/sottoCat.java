package com.market.model;

public class sottoCat {
    private String nome_sott;
    private String nome_cat;

    public Integer getId_cat() {
        return id_cat;
    }

    public void setId_cat(Integer id_cat) {
        this.id_cat = id_cat;
    }

    private Integer id_cat;


    public String getNome_cat() {
        return this.nome_cat;
    }

    public void setNome_cat(String nome_cat) {
        this.nome_cat = nome_cat;
    }




    public String getNome_sott() {
        return this.nome_sott;
    }


    public void setNome_sott(String nome_sot) {
        this.nome_sott = nome_sot;
    }


}
