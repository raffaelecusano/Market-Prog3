package com.market.model;

public class Prodotto {

    private Integer id_prod;
    private String nome;
    private String descrizione;
    private Float prezzo;
    private Integer scorta;

    public Integer getId_prod() {
        return id_prod;
    }

    public void setId_prod(Integer id_prod) {
        this.id_prod = id_prod;
    }


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }


    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public Float getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(Float prezzo) {
        this.prezzo = prezzo;
    }

    public Integer getScorta() {
        return scorta;
    }

    public void setScorta(Integer scorta) {
        this.scorta = scorta;
    }


}
