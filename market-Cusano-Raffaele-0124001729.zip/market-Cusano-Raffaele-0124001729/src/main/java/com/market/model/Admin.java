package com.market.model;

//import com..market3.marketing.AdminPanel;
//import com.example.market3.marketing.Offer;


public class Admin implements TypeUser{

    /*
    private AdminPanel adminPanel;
*/
    public Admin(){
        //this.adminPanel = new AdminPanel();
    }

    @Override
    public String doAct(){ return "Sono un admin"; }

    /*
    @Override
    public void insProd(ProdItem prodotto){
        getDAO().insProd(prodotto);
    }

    @Override
    public void editProd(ProdItem prodotto){
        getDAO().editProd(prodotto);
    }

    @Override
    public int addToCart(Integer id){
        System.out.println("ADMIN non configurato per acquisti");
        return -1; //ritorno -1 per indicare che non è possibile eseguire questa operazione
    }

    @Override
    public int getCartItemN(){
        System.out.println("ADMIN non configurato per acquistare");
        return -1;
    }

    @Override
    public List<ProdPreview> getCartItemView(){
        System.out.println("ADMIN non configurato per acquistare");
        return null;
    }

    @Override
    public int removeCartItem(Integer id){
        System.out.println("ADMIN non configurato per acquistare");
        return -1; //-1 segnala che l'operazione non è possibile per il tipo di utente selezionato
    }

    @Override
    public int pay(PaymentStrategy paymentMethod){
        System.out.print("ADMIN non configurato per acquistare");
        return -1; //-1 segnala che l'operazione non è possibile per il tipo di utente selezionato
    }

    @Override
    public AdminPanel getAdminPanel() {
        return adminPanel;
    }

    @Override
    public ArrayList<Offer> getMyOffer(){
        System.out.println("Utente non abiliato a questa operazione");
        return null;
    }

    @Override
    public int addOfferToCart(Integer idOffer,Integer id, Double discountPrice){
        System.out.println("Admin non configurato per questa operazione");
        return -1;
    }

    @Override
    public int deleteProd(Integer idProd){
        int retValue = getDAO().deleteProduct(idProd);
        return retValue;
    }
    
    @Override
    public int checkNewOffer(){
        System.out.println("Non configurato per questa operazione");
        return -1;
    }
    */
}
