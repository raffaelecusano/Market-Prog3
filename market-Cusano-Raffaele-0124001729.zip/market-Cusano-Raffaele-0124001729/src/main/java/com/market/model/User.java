package com.market.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


public class User {


    private String username;

    private String password;

    private String nome;

    private String cognome;

    private String email;

    private String role;

    public User(){}

    public User(String Usern, String password,String email, String nome, String cognome,  String role){
        this.username= Usern;
        this.password=   password;
        this.email= email;
        this.nome=  nome;
        this.cognome= cognome;
        this.role= role;

    }

    public TypeUser getTypeUsr() {
        return TypeUsr;
    }

    public void setTypeUsr(TypeUser typeUsr) {
        TypeUsr = typeUsr;
    }

    private TypeUser TypeUsr;

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }



    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}



