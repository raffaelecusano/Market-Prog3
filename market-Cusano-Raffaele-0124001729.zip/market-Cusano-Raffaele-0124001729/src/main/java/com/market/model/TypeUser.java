package com.market.model;

//import com.example.market3.marketing.AdminPanel;
//import com.example.market3.marketing.Offer;

import java.util.ArrayList;
import java.util.List;

public interface TypeUser {

    public String doAct();
    /*
    public void insProd(ProdItem prodotto);
    public void editProd(ProdItem prodotto);
    public int addToCart(Integer id) throws CloneNotSupportedException;
    public int getCartItemN();
    public List<ProdPreview> getCartItemView();
    public int removeCartItem(Integer id);
    public int pay(PaymentStrategy paymentMethod);
    public AdminPanel getAdminPanel();
    public ArrayList<Offer> getMyOffer();
    public int addOfferToCart(Integer idOffer,Integer id, Double discountPrice);
    public int deleteProd(Integer idProd);
    public int checkNewOffer();


     */
}
