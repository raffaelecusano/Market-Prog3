package com.market.DAO;


import com.market.model.Acquisti;
import com.market.model.Prodotto;
import com.market.model.User;
import com.market.model.sottoCat;
import com.market.prototype.Ricevuta;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

enum SRC_BYID_QRY{
    ONE {
        public String toString() {
            return "SELECT * FROM libro WHERE id = ? limit 1";
        }
    },
    TWO{
        public String toString() {
            return "SELECT * FROM album WHERE id = ? limit 1";
        }
    },
    THREE{
        public String toString(){
            return "SELECT * FROM strumentomusic WHERE id = ? limit 1";
        }
    },
    FOUR{
        public String toString(){
            return "SELECT * FROM film WHERE id = ? limit 1";
        }
    }
}


public class DAO {

    private static DAO dao;
    private Connection conn;
   // private ProdVisitorImpl prodVisitor;
    private BufferedReader fread;
    private FileWriter fwrite;
    private File IDfile;
    private File ricevutaFile;
    private File transactionFile;
    //per mantenere l'univocità dell'ID tra le diverse tabelle dei prodotti salvo l'utlimo ID(un numero che viene
    //aumentato ad ogni inserimento) in un file che vado a recuperare ogni volta che inserisco un prodotto e aggiorno
    //chiaramente rappresentando l'ultimo ID usato il numero presente nel file va prima incrementato per poi essere usato
    //la stessa cosa vale per ricevutaFile e transactionFile che conservano il numero progressivo del numero di ricevuta
    //e del numero della transazione
    private File numberOfProds; //file che contiene il numero di prodotti totali presenti nello store
    private File offerFile; //contiene l'ID dell'ultima offerta



    private DAO() {
        Connect connect = new Connect();
        conn = connect.getConnection();
    }

    public static DAO getDAO(){
        if( dao==null )
            dao = new DAO();
        return dao;
    }

    public void register(User user) {

        String INSERT_QUERY = "insert into UTENTE values(?,?,?,?,?,?)";

        try (
            PreparedStatement prepareStatement = conn.prepareStatement(INSERT_QUERY)) {
            prepareStatement.setString(1, user.getUsername());
            prepareStatement.setString(2, user.getPassword());
            prepareStatement.setString(4,user.getNome());
            prepareStatement.setString(5,user.getCognome());
            prepareStatement.setString(3,user.getEmail());
            prepareStatement.setString(6,"CLIENTE"); //di default le registrazioni effetuate dal sito vengono salvate come cliente
//            prepareStatement.setInt(7,user.getPhone());
            System.out.println("Utente:"+user.getNome()+" "+user.getCognome());
            prepareStatement.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }


    public User findUsername(String s){

        String USR_QUERY = "SELECT * FROM UTENTE u WHERE u.username = ?  limit 1";
        User user = new User();
        try {
            PreparedStatement prepareStatement = conn.prepareStatement(USR_QUERY);
            prepareStatement.setString(1,s);
            ResultSet rs = prepareStatement.executeQuery();
            if( rs.next() ){
                user.setUsername(rs.getString("username"));
                user.setNome(rs.getString("nome"));
                user.setPassword(rs.getString("password"));
                user.setCognome(rs.getString("cognome"));
                user.setRole(rs.getString("role"));
            }
            else {
                rs.close();
                String USR_QUERY1 = "SELECT * FROM AMMINISTRATORI a WHERE a.username = ?  limit 1";
                PreparedStatement prepareStatement1 = conn.prepareStatement(USR_QUERY1);
                prepareStatement1.setString(1,s);
                ResultSet rs1 = prepareStatement1.executeQuery();
                if( rs1.next() ){
                    user.setUsername(rs1.getString("username"));
                    user.setNome(rs1.getString("nome"));
                    user.setPassword(rs1.getString("password"));
                    user.setCognome(rs1.getString("cognome"));
                    user.setRole(rs1.getString("role"));
                }
            }


        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return user;
    }


    public ArrayList<String> getCategories()
    {
        String CATEGORIES_QRY = "SELECT DISTINCT NOME_CAT from CATEGORIE";
        ArrayList<String> categories = new ArrayList<>();
        try {
            PreparedStatement prepareStatement = conn.prepareStatement(CATEGORIES_QRY);
            ResultSet rs = prepareStatement.executeQuery();
            while ( rs.next() ){
                String str;
                str = rs.getString("NOME_CAT");
                categories.add(str);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return categories;
    }

    public ArrayList<sottoCat> getSottoCategories()
    {
        String CATEGORIES_QRY = "SELECT DISTINCT NOME_SOT, NOME_CAT, ID_CAT FROM CATEGORIE ";
        ArrayList<sottoCat> Scategories = new ArrayList<>();
        try {
            PreparedStatement prepareStatement = conn.prepareStatement(CATEGORIES_QRY);
            ResultSet rs = prepareStatement.executeQuery();
            while ( rs.next() ){
                String rt;
               sottoCat sot = new sottoCat();
                sot.setNome_sott(rs.getString("NOME_SOT"));
                System.out.println("Sottocat dao"+sot.getNome_sott()+"\n");
                sot.setNome_cat(rs.getString("NOME_CAT"));
                sot.setId_cat(rs.getInt("ID_CAT"));
                Scategories.add(sot);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return Scategories;
    }


    public ArrayList<Prodotto> getProduct (Integer id){
        ArrayList<Prodotto> myProd= new ArrayList<>();
        String qry_prod= "SELECT ID_PROD,NOME,DESCRIZIONE,PREZZO,SCORTA FROM PRODOTTO WHERE ID_CAT="+id;
        try {
            PreparedStatement prepareStatement = conn.prepareStatement(qry_prod);
            ResultSet rs = prepareStatement.executeQuery();
            while( rs.next() ){
                Prodotto prod = new Prodotto();
                prod.setId_prod( rs.getInt("id_prod") );
                prod.setNome( rs.getString("nome") );
                prod.setDescrizione( rs.getString("descrizione") );
                prod.setPrezzo( rs.getFloat("prezzo") );
                prod.setScorta( rs.getInt("scorta") );
                myProd.add(prod);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return myProd;

    }



    public ArrayList<Prodotto> getCategoryProducts(String sottoCategoria)
    {
        ArrayList<Prodotto> prodotti = new ArrayList<>();
        String qry_idSotto = "SELECT ID_CAT,NOME_SOT FROM CATEGORIE WHERE NOME_SOT= ?";
        Integer idSot = 0;
        try {
            PreparedStatement prepareStatement = conn.prepareStatement(qry_idSotto);
            prepareStatement.setString(1,sottoCategoria);
            ResultSet rs = prepareStatement.executeQuery();
            while( rs.next() ){
                idSot= rs.getInt("ID_CAT");
            }
            rs.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        String CATEGORIES_QRY = "SELECT ID_PROD, NOME, DESCRIZIONE, PREZZO, SCORTA from PRODOTTO WHERE ID_CAT="+idSot;
        try {
            PreparedStatement prepareStatement = conn.prepareStatement(CATEGORIES_QRY);
            ResultSet rs = prepareStatement.executeQuery();
            while( rs.next() ){
                Prodotto prod = new Prodotto();
                prod.setId_prod( rs.getInt("id_prod") );
                prod.setNome( rs.getString("nome") );
                prod.setDescrizione( rs.getString("descrizione") );
                prod.setPrezzo( rs.getFloat("prezzo") );
                prod.setScorta( rs.getInt("scorta") );
                if(prod.getScorta()>0)
                    prodotti.add(prod);

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return prodotti;
    }

        public Prodotto getProdcutbyId(Integer id){

        String qryProdotto = "SELECT * FROM PRODOTTO WHERE ID_PROD="+id;
            Prodotto prod = new Prodotto();
            try {
                PreparedStatement prepareStatement = conn.prepareStatement(qryProdotto);
                ResultSet rs = prepareStatement.executeQuery();
                while( rs.next() ){

                    prod.setId_prod( rs.getInt("id_prod") );
                    prod.setNome( rs.getString("nome") );
                    prod.setDescrizione( rs.getString("descrizione") );
                    prod.setPrezzo( rs.getFloat("prezzo") );
                    prod.setScorta( rs.getInt("scorta") );

                }
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            return prod;
        }


        public Integer addBill(Ricevuta ric){
                String qry = " INSERT INTO RICEVUTA(data,username,totale,metodo_pag) VALUES (?,?,?,?)";
                Integer id_ric=0;
            try {
                PreparedStatement prepareStatement = conn.prepareStatement(qry);
                prepareStatement.setDate(1,ric.getData_acq());
                prepareStatement.setString(2,ric.getUsername());
                prepareStatement.setDouble(3,ric.getTotale());
                prepareStatement.setInt(4,ric.getMetodo_p());
                boolean i= prepareStatement.execute();
                
               
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            String qry1 = " SELECT ID_RICEVUTA FROM RICEVUTA  ORDER BY ID_RICEVUTA DESC LIMIT 1";
            try {
                PreparedStatement PS = conn.prepareStatement(qry1);
                ResultSet rs1= PS.executeQuery();
                while(rs1.next()){
                    id_ric=rs1.getInt("ID_RICEVUTA");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return id_ric;
        }
        
        public void remScorta(Integer id){
        String qry="SELECT SCORTA FROM PRODOTTO WHERE ID_PROD="+id;
        Integer sc=0;
            try {
                PreparedStatement ps= conn.prepareStatement(qry);
                ResultSet rs = ps.executeQuery();
                while (rs.next()){
                    sc= rs.getInt("SCORTA");

                }
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            sc=sc-1;
            if(sc >0 ){

                String qr2= "UPDATE PRODOTTO SET SCORTA=? WHERE ID_PROD="+id;
                try {
                    PreparedStatement ps= conn.prepareStatement(qr2);
                    ps.setInt(1,sc);
                    Boolean b = ps.execute();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

        }

        public void addAcq(ArrayList<Acquisti> acq){
            String qry="INSERT INTO ACQUISTI(ID_RICEVUTA, ID_PRODOTTO, QNT) VALUES (?,?,?)";
            for(Acquisti a: acq){
                try {
                    PreparedStatement ps = conn.prepareStatement(qry);
                    ps.setInt(1,a.getId_ricevuta());
                    ps.setInt(2,a.getId_prodotti());
                    ps.setInt(3,a.getQnt());
                    Boolean b = ps.execute();
                    ps.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }



        public ArrayList<Prodotto> allProduct(){
        String qry = " SELECT * FROM PRODOTTO";
        ArrayList<Prodotto> arr = new ArrayList<>();

            try {
                PreparedStatement ps = conn.prepareStatement(qry);
                ResultSet rs = ps.executeQuery();
                while (rs.next()){
                    Prodotto p = new Prodotto();
                    p.setId_prod(rs.getInt("ID_PROD"));
                    p.setNome(rs.getString("NOME"));
                    p.setDescrizione(rs.getString("DESCRIZIONE"));
                    p.setPrezzo( rs.getFloat("PREZZO"));
                    p.setScorta(rs.getInt("SCORTA"));
                    arr.add(p);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        return arr;
        }

        public Boolean insertProd(Prodotto p, Integer cat){

        String qry= " INSERT INTO PRODOTTO( ID_CAT, NOME, DESCRIZIONE, PREZZO, SCORTA) VALUES (?,?,?,?,?)";
            try {
                PreparedStatement ps = conn.prepareStatement(qry);
                ps.setString(2,p.getNome());
                ps.setInt(1,cat);
                ps.setString(3,p.getDescrizione());
                ps.setFloat(4, p.getPrezzo());
                ps.setInt(5,p.getScorta());
                Boolean b = ps.execute();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return true;
        }

        public void remProd(Integer id){
            String qry="UPDATE PRODOTTO SET SCORTA=0 WHERE ID_PROD="+id;

            try {
               PreparedStatement ps = conn.prepareStatement(qry);
                Boolean b= ps.execute();

            } catch (SQLException e) {
                e.printStackTrace();
            }


        }
    public void addQnt(Integer id){
        String qry="SELECT SCORTA FROM PRODOTTO WHERE ID_PROD="+id;
        Integer sco=0;
        try {
            PreparedStatement ps = conn.prepareStatement(qry);
            ResultSet b= ps.executeQuery(qry);
            while(b.next()){
                sco=b.getInt("SCORTA")+1;
            }
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        String qry1="UPDATE PRODOTTO SET SCORTA=? WHERE ID_PROD="+id;
        System.out.println("Scorta aumentata di 1: "+sco);
        try {
            PreparedStatement ps = conn.prepareStatement(qry1);
            ps.setInt(1,sco);
            Boolean b= ps.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }


    }

        public ArrayList<Integer> getRicevutabyUser(String username){

        String qry = "SELECT ID_RICEVUTA FROM RICEVUTA WHERE USERNAME=?";
        ArrayList<Integer> ric= new ArrayList<>();
            try {
                PreparedStatement ps= conn.prepareStatement(qry);
                ps.setString(1,username);
                ResultSet rs = ps.executeQuery();
                while (rs.next())
                {
                    ric.add(rs.getInt("ID_RICEVUTA"));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

            return ric;
        }

        public HashMap<String, ArrayList> getProdByRic(Integer ric){

        String qry1 = "SELECT ID_PRODOTTO,QNT FROM ACQUISTI WHERE ID_RICEVUTA="+ric;
        ArrayList<Integer> idProd = new ArrayList<>();
        ArrayList<Integer> qnt = new ArrayList<>();
            try {
                PreparedStatement ps = conn.prepareStatement(qry1);
                ResultSet rs = ps.executeQuery();
                while(rs.next()){
                    idProd.add(rs.getInt("ID_PRODOTTO"));
                    qnt.add(rs.getInt("QNT"));
                }
                ps.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            String qry2 = "SELECT NOME FROM PRODOTTO WHERE ID_PROD=?";
            ArrayList<String> myProd = new ArrayList<>();

            for(Integer id : idProd){
                try {
                    PreparedStatement ps = conn.prepareStatement(qry2);
                    ps.setInt(1,id);
                    ResultSet rs = ps.executeQuery();
                    while(rs.next()){
                        myProd.add(rs.getString("NOME"));

                    }
                    ps.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }

            }
            HashMap<String,ArrayList> retVal = new HashMap<>();
            retVal.put("prod", myProd);
            retVal.put("qnt", qnt);
            return retVal;
        }
}



