package com.market.DAO;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class Connect {

    private Connection connection = null;

    private static final String DATABASE_DRIVER = "org.mariadb.jdbc.Driver";
    private static final String DATABASE_URL = "jdbc:mariadb://localhost:3306/dbmagazzino?user=root&password=";

    private String jdbcDriver;
    private String databaseUrl;

    Connect() {
        Properties properties = new Properties();
        try {
            jdbcDriver = properties.getProperty("driver", DATABASE_DRIVER);
            databaseUrl = properties.getProperty("url", DATABASE_URL);
            connection = DriverManager.getConnection(DATABASE_URL);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public Connection getConnection() {
        return connection;
    }

}
