package com.market.prototype;

import java.lang.Cloneable;
import java.util.HashMap;
import java.util.Map;

import java.sql.Date;

public abstract  class Ricevuta implements Cloneable {


    public String getId_ricevuta() {
        return id_ricevuta;
    }

    public void setId_ricevuta(String id_ricevuta) {
        this.id_ricevuta = id_ricevuta;
    }

    public Date getData_acq() {
        return data_acq;
    }

    public void setData_acq(Date data_acq) {
        this.data_acq = data_acq;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Double getTotale() {
        return totale;
    }

    public void setTotale(Double totale) {
        this.totale = totale;
    }

    public Integer getMetodo_p() {
        return metodo_p;
    }

    public void setMetodo_p(Integer metodo_p) {
        this.metodo_p = metodo_p;
    }

    protected String id_ricevuta;
    protected Date data_acq;
    protected String username;
    protected Double totale;
    protected Integer metodo_p;


    abstract void addMethod();

    public Object clone()
    {
        Object clone = null;
        try
        {
            clone = super.clone();
        }
        catch (CloneNotSupportedException e)
        {
            e.printStackTrace();
        }
        return clone;
    }

    static class credito extends Ricevuta{

        public credito(){
            this.metodo_p=(Integer) 1;
        }
        @Override
        void addMethod() {

        }


    }

    static class debito extends Ricevuta{

        public debito(){
            this.metodo_p=(Integer) 2;
        }


        @Override
        void addMethod() {

        }
    }

    static class payp extends Ricevuta{

        public payp(){
            this.metodo_p=(Integer) 3;
        }
        @Override
        void addMethod(){
        }


    }

    public static class MethodStore{


        private static Map<String, Ricevuta> methodMap = new HashMap<String, Ricevuta>();

        public MethodStore()
        {
            methodMap.put("credito", new credito());
            methodMap.put("debito", new debito());
            methodMap.put("paypal",new payp());

        }
        public Ricevuta getRicevuta(String method)
        {


            return (Ricevuta) methodMap.get(method).clone();
        }

    }


}
