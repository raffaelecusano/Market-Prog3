package com.market.service;

//import com.example.market3.model.Admin;
//import com.example.market3.model.Cliente;
import com.market.model.Admin;
import com.market.model.Cliente;
import org.springframework.security.core.userdetails.User.UserBuilder;
import com.market.model.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import static com.market.DAO.DAO.getDAO;

public class UserDetailsServiceImp implements UserDetailsService{

    public static User usr;

    public static User getUsr() {
        return usr;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        usr = getDAO().findUsername(username);

        UserBuilder builder = null;
        if(usr!=null){
            builder = org.springframework.security.core.userdetails.User.withUsername(username);
            builder.password(new BCryptPasswordEncoder().encode(usr.getPassword()) );
            builder.roles(usr.getRole());
            System.out.println(usr.getRole());
            if( usr.getRole().equals("ADMIN") )
            {
                Admin admin = new Admin();
                usr.setTypeUsr(admin);
            }else
            {
                Cliente cliente = new Cliente(username);
                usr.setTypeUsr(cliente);
            }
        }else{
            throw new UsernameNotFoundException("User not found.");
        }

        return builder.build();
    }
}
