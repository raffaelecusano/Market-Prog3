package com.market.Strategy;

public class CreditPay implements Pagamento {

    @Override
    public double pay(double costo) {
        return costo -= costo *3/100;

    }
}
