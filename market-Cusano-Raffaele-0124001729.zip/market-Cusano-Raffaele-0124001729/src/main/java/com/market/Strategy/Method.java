package com.market.Strategy;

public enum Method {
    credito,
    debito,
    paypal
}
