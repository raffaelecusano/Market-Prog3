package com.market.Strategy;

public interface Pagamento {
    double pay(double costo);
}
