package com.market.Strategy;

public class PaymentStrategy {
    private Pagamento pagamento;

     public PaymentStrategy(Pagamento p){
         this.pagamento=p;
     }

     public Pagamento getPagamento(){
         return pagamento;
     }

     public void paga(double costo){
         pagamento.pay(costo);
     }
}
