package com.market.Strategy;

public class DebitPay implements Pagamento{

    @Override
    public double pay(double costo) {
        return costo -= costo*1.5/100;
    }
}
