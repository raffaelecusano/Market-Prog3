package com.market.Strategy;

import com.market.model.Prodotto;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;

public class Carrello {
    private ArrayList<Prodotto> items;

    public Carrello() {
        items = new ArrayList<>();
    }

    public void addItem(Prodotto item) {

        items.add(item);
    }

    public ArrayList<Prodotto> getItems(){
        if (!(this.items.isEmpty())) {
            return this.items;
        }
        else {
            return new ArrayList<>();
        }
    }
    public void remItem(int id){


        for(int i =0;i<items.size();i++){
            if(items.get(i).getId_prod()==id)
                items.remove(i);
        }

    }
    public double calcTotalCost() {

        double total = 0.0;
        for (Prodotto item : items) {

            total += item.getPrezzo();
        }
        BigDecimal bd = new BigDecimal(total);

        return Double.valueOf(String.valueOf(bd.round(new MathContext(3))));
    }

    /*public boolean pay(PaymentMethod method) {

        double totalCost = calcTotalCost();
        return method.pay(totalCost);
    }

     */
}
