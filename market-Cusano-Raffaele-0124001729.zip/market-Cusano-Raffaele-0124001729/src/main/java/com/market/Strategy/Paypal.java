package com.market.Strategy;

public class Paypal implements Pagamento{

    @Override
    public double pay(double costo) {
        return costo += costo * 4.5/100;
    }
}
