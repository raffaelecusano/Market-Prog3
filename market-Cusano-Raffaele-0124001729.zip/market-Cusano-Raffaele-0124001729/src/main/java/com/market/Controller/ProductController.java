package com.market.Controller;

import com.market.model.Prodotto;
import com.market.model.sottoCat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Objects;

import static com.market.DAO.DAO.getDAO;
@Controller
public class ProductController {
    @RequestMapping(value = "/Catalogo", method = RequestMethod.GET)
    public String showCategories(Model model) {
        ArrayList<String> cat = getDAO().getCategories();
        model.addAttribute("categorie", cat);
        return "showCategories";
    }


    @RequestMapping(value = "/Catalogo/{categoria}", method = RequestMethod.GET)
    public String baseProdotti(HttpServletRequest request, @PathVariable("categoria") String categoria, Model model) {

       // String categoria = request.getPathInfo().substring(1);
        System.out.println("la categoria è "+ categoria+ "\n");
        model.addAttribute("categoria", categoria);
        //model.addAttribute("categorie", cat);
        ArrayList<sottoCat> sCat = getDAO().getSottoCategories();
        ArrayList<String> sotto = new ArrayList<>();
        ArrayList<Integer> prod = new ArrayList<>();
        for (sottoCat i : sCat) {
            if (Objects.equals(i.getNome_cat(), categoria)) {
                sotto.add(i.getNome_sott());
                prod.add(i.getId_cat());
            }
        }
        ArrayList<Prodotto> myProd = new ArrayList<>();
        for (int j=0;j<prod.size();j++){
            myProd.addAll(getDAO().getProduct(prod.get(j)));
        }


        model.addAttribute("sottoCategorie", sotto);
        model.addAttribute("prodotti", myProd);

        return "categoryProducts";
    }


    @RequestMapping(value = "/Catalogo/{categoria}/{sottoCategoria}", method = RequestMethod.GET)
    public String subCategory (@PathVariable("categoria") String categoria, @PathVariable("sottoCategoria") String sCat, Model model){

        String sottocate= "";
        try {
            sottocate = URLDecoder.decode(sCat, StandardCharsets.UTF_8.toString());
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        ArrayList<Prodotto> myProds = getDAO().getCategoryProducts(sottocate);
        model.addAttribute("prodotti", myProds);
        model.addAttribute("sottocategoria", sottocate);

        ArrayList<sottoCat> soCat = getDAO().getSottoCategories();
        ArrayList<String> sotto = new ArrayList<>();

        for (sottoCat i : soCat) {
            if (Objects.equals(i.getNome_cat(), categoria)) {
                sotto.add(i.getNome_sott());
            }
        }

        model.addAttribute("sottoCategorie", sotto);

        return "categoryProducts";
    }



    @RequestMapping(value = "/Catalogo/{categoria}/view/{id_prodotto}", method = RequestMethod.GET)
    public String getProd(@PathVariable("categoria") String categoria,@PathVariable("id_prodotto") Integer idProd, Model model){

        Prodotto myProd = getDAO().getProdcutbyId(idProd);
        model.addAttribute("prodotto",myProd);
       // model.addAttribute("sottoCategoria",sCat);
        model.addAttribute("categoria",categoria);

     return "descProdotto";
    }

}

