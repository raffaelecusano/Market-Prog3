package com.market.Controller;

//import com.example.market3.service.UserDetailsServiceImp;
import com.market.service.UserDetailsServiceImp;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    };

    public UserDetailsService userDetailsService() {
        return new UserDetailsServiceImp();
    };

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService()).passwordEncoder(passwordEncoder());
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                .antMatchers("/home")
                .permitAll()
                .antMatchers("/")
                .permitAll()
                .antMatchers("/register")
                .permitAll()
                .antMatchers("/registerProcess")
                .permitAll()
                .antMatchers("/login*")
                .permitAll()
                .antMatchers("/loginProcess")
                .permitAll()
                .antMatchers("//img/home.jpg")
                .permitAll()
                .antMatchers("/showCategories")
                .permitAll()
                .antMatchers("/img/logo.jpg")
                .permitAll()
                .antMatchers("/img/register.jpg")
                .permitAll()
                .antMatchers("/adminPanel")
                .hasRole("ADMIN")
                .antMatchers("/groupBy/**")//con gli asterischi specifico tutti gli indirizzi a partire da /groupBy/
                .hasRole("ADMIN")
                .antMatchers("/sendOffer")
                .hasRole("ADMIN")
                .anyRequest()
                .hasAnyRole("ADMIN", "CLIENTE")
                .and()
                .formLogin()
                //.loginPage("/login")
                .loginProcessingUrl("/loginProcess")
                .defaultSuccessUrl("/home", true)
                .and()
                .logout().permitAll().logoutSuccessUrl("/home")
                .and()
                .csrf().disable();
    }


}
