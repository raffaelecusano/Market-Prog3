package com.market.Controller;

//import com.market.marketing.Offer;

import com.market.Factory.categoryFactory;
import com.market.model.Prodotto;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;

import static com.market.DAO.DAO.getDAO;


@Controller
public class AdminController {

    @RequestMapping(value = "/adminPanel", method = RequestMethod.GET)
    public String showPanel(Model model){
        String username="";
        model.addAttribute("username",username);
        ArrayList<String> p = new ArrayList<>();
        p.add("");
        model.addAttribute("prodotti",p);
        ArrayList<String> qua= new ArrayList<>();
        qua.add("");
        model.addAttribute("quantita", qua);

        return "adminPanel";
    }

    @RequestMapping(value = "/queryResult", method = RequestMethod.POST)
    public String panelWithQry(Model model, @RequestParam String username){
        System.out.println("USERNAME: "+ username);
        model.addAttribute("username",username);

        ArrayList<Integer> ric = getDAO().getRicevutabyUser(username);
        ArrayList<String> nomeProd = new ArrayList<>();
        ArrayList<Integer> qua = new ArrayList<>();
        for( Integer r:ric){

            HashMap<String, ArrayList> map = getDAO().getProdByRic(r);
            nomeProd.addAll(map.get("prod"));
            qua.addAll(map.get("qnt"));

        }
       model.addAttribute("prodotti", nomeProd);
       model.addAttribute("quantita", qua);
       System.out.println("nome prod:"+nomeProd.get(0)+"\n");
       System.out.println("quantità prod:"+qua.get(0)+"\n");


        return "adminPanel";
    }

    @RequestMapping(value="/insertProd", method= RequestMethod.GET)
    public String insProd(Model model){
        Prodotto p = new Prodotto();
        model.addAttribute("prodotto",p);
        String cat="";
        model.addAttribute("cat",cat);

        return "insertProd";

    }
    @RequestMapping(value="/listProd", method= RequestMethod.GET)
    public String showProd(Model model){
        ArrayList<Prodotto> a= getDAO().allProduct();
        model.addAttribute("prodotti",a);

        return "listProd";

    }

    @RequestMapping(value="/insProd_process", method= RequestMethod.POST)
    public String insertProd(@ModelAttribute(value="prodotto")Prodotto p, @RequestParam String cat){
        //qua utilizzeremo la factory categorie per ricavare gli id interi da inserire nel db per ogni oggetto.
        //l'admin quando inserirà un prodotto dovra solo selezionare la cat con la sottocat e la facotry restituirà
        // l'intero corretto della categoria

        System.out.println("In input:"+p.getNome()+" "+p.getPrezzo()+" "+cat+"\n");
        Integer cat_db = categoryFactory.getInstance().getAction(cat);
        System.out.println("catdb = "+cat_db+"\n");
        Boolean b=getDAO().insertProd(p,cat_db);

        System.out.println("la dao:"+b+"\n");

        return "redirect:/home";

    }

    @RequestMapping(value = "/listProd/rem/{id}", method = RequestMethod.POST)
    public String remCart(HttpServletRequest request, HttpServletResponse response,
                          @PathVariable("id") Integer idProd, Model model ){

        getDAO().remProd(idProd);


        return "redirect:/listProd";
    }
    @RequestMapping(value = "/listProd/add/{id}", method = RequestMethod.POST)
    public String addQnt(HttpServletRequest request, HttpServletResponse response,
                          @PathVariable("id") Integer idProd, Model model ){

        getDAO().addQnt(idProd);


        return "redirect:/listProd";
    }



}
