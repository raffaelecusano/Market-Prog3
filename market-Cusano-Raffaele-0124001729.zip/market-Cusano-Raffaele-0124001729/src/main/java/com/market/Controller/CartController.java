package com.market.Controller;

import com.market.Strategy.Carrello;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import static com.market.DAO.DAO.getDAO;
@Controller
public class CartController {

    @RequestMapping(value = "/Carrello/rem/{id}", method = RequestMethod.POST)
    public String remCart(HttpServletRequest request, HttpServletResponse response,
                            @PathVariable("id") Integer idProd, Model model ){

        System.out.println("il mio id preso è :"+idProd+"\n");


        HttpSession session = request.getSession(true);
        Carrello cart;

        cart = (Carrello) session.getAttribute("carrello");
        cart.remItem(idProd);
        double prezzo = cart.calcTotalCost();
        model.addAttribute("costo", prezzo);
        session.removeAttribute("carrello");
        session.setAttribute("carrello", cart);
        model.addAttribute("prodotti",cart.getItems());

        return "redirect:/Carrello";
    }

    @RequestMapping(value = "/Carrello/{id}", method = RequestMethod.POST)
    public String insertCart(HttpServletRequest request, HttpServletResponse response,
                             @PathVariable("id") Integer idProd, Model model ){

        System.out.println("il mio id preso è :"+idProd+"\n");


        HttpSession session = request.getSession(true);
        Carrello cart = new Carrello();
        if (session.getAttribute("carrello")!=null) {
            cart = (Carrello) session.getAttribute("carrello");
            cart.addItem(getDAO().getProdcutbyId(idProd));
            session.removeAttribute("carrello");
            session.setAttribute("carrello", cart);
        }else {
            cart.addItem(getDAO().getProdcutbyId(idProd));
            session.setAttribute("carrello", cart);
        }

        double prezzo = cart.calcTotalCost();
        model.addAttribute("costo", prezzo);
        model.addAttribute("prodotti",cart.getItems());

        return "redirect:/Carrello";
    }

    @RequestMapping(value = "/Carrello", method = RequestMethod.GET)
    public String viewCart(HttpServletRequest request, HttpServletResponse response, Model model){
        HttpSession session = request.getSession(true);
        Carrello cart = new Carrello();
        if (session.getAttribute("carrello")!=null) {
            cart = (Carrello) session.getAttribute("carrello");

        }else {
            session.setAttribute("carrello", cart);
        }
        double prezzo = cart.calcTotalCost();
        model.addAttribute("costo", prezzo);
        model.addAttribute("prodotti",cart.getItems());

        return "carrello";
    }
}
