package com.market.Controller;

import com.market.Factory.paymentFactory;
import com.market.Strategy.Carrello;
import com.market.Strategy.Pagamento;
import com.market.model.Acquisti;
import com.market.model.Prodotto;
import com.market.prototype.Ricevuta;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.Calendar;

import static com.market.DAO.DAO.getDAO;

@Controller
public class CheckoutController {



    @RequestMapping(value="/checkout/{costo}", method= RequestMethod.POST)
    public String paga(HttpServletRequest request, HttpServletResponse response,
                       @ModelAttribute("payment") String pay, @PathVariable("costo")double cost, Model model){

        System.out.println("La modalita di pagamento:"+pay+"\n");
        HttpSession session = request.getSession(true);
        session.setAttribute("method",pay);
        //FActory che fa eseguire il pagamento corretto
        Pagamento p=paymentFactory.getInstance().getAction(pay);
        double cost_f = p.pay(cost);


        model.addAttribute("costo", cost_f);
        return pay;

    }

    @RequestMapping(value="/checkout/paymentStatus", method= RequestMethod.POST)
    public String postPay(HttpServletRequest request, HttpServletResponse response
                      ){


        HttpSession session = request.getSession(true);
        String method= (String) session.getAttribute("method");
        Carrello cart= (Carrello) session.getAttribute("carrello");

        Pagamento p=paymentFactory.getInstance().getAction(method);
        double cost = p.pay(cart.calcTotalCost());

        //Il prototype pattern mi permette di generare già una ricevuta con quel metodo di pagamento
        // in modo da risparmiare tempo e non occupare memoria inutile
        Ricevuta ric= new Ricevuta.MethodStore().getRicevuta(method);

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String name = auth.getName();

        ric.setUsername(name);
        ric.setData_acq(new java.sql.Date(Calendar.getInstance().getTime().getTime()));

        /*switch (method) {
            case "credito":
                ric.setMetodo_p(1 );
                break;
            case "debito":
                ric.setMetodo_p(2 );
                break;
            case "paypal":
                ric.setMetodo_p(3 );
                break;
        }
*/
        ric.setTotale(cost);

       Integer id_ric= getDAO().addBill(ric);



        ArrayList<Acquisti> acq= new ArrayList<>();


        for(Prodotto pp : cart.getItems()){
            getDAO().remScorta(pp.getId_prod());

            if(!acq.isEmpty()){
                for(Acquisti a: acq){
                    if(a.getId_prodotti().equals(pp.getId_prod())){
                        a.setQnt(a.getQnt()+1);
                    }
                }
                Acquisti ac= new Acquisti();
                ac.setId_prodotti(pp.getId_prod());
                ac.setQnt(1);
                ac.setId_ricevuta(id_ric);
                acq.add(ac);
            }
            else{
                Acquisti ac= new Acquisti();
                ac.setId_prodotti(pp.getId_prod());
                ac.setQnt(1);
                ac.setId_ricevuta(id_ric);
                acq.add(ac);
            }
        }
        getDAO().addAcq(acq);
        session.removeAttribute("carrello");

        return "home";

    }
}
