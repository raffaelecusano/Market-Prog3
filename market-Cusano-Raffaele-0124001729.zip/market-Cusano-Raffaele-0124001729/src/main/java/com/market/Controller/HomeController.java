package com.market.Controller;



import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/")
    public String rootPage() { return "home"; }

    @GetMapping("/home")
    public String home(){
        return "home";
    }

    //Quando è richiesta la pagina di login si attiva la pagina di autenticazione
    //di spring security di default, questo perchè non ne è specificata una in particolare
    //e tutte le pagine del sito sono accessibili dopo autenticazione
    //compreso il dominio /login. Dopo si è reinderizzati alla home che è il valore
    //di ritorno di default per qeusto dominio.
   /* @GetMapping("/login")
    public String login(){ return "login"; }

    */

}
