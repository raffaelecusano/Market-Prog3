package com.market.Controller;

import com.market.model.Login;
import com.market.model.User;
import org.springframework.security.core.userdetails.User.UserBuilder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Objects;

import static com.market.DAO.DAO.getDAO;

@Controller
public class LoginController {

  @GetMapping("/login")
    public String doLogin (HttpServletRequest request, HttpServletResponse response)
    {

        return "login";
    }


    @RequestMapping(value = "/loginProcess", method = RequestMethod.POST)
    public String retriveUser(HttpServletRequest request, HttpServletResponse response,
                                    @ModelAttribute("login") Login login) {


        User user = getDAO().findUsername(login.getUsername());
        if (Objects.equals(user.getPassword(),login.getPassword())){
            HttpSession session = request.getSession(true);
            session.setAttribute("utente", user);//assegno l'utente alla sessione attuale

            UserBuilder builder =org.springframework.security.core.userdetails.User.withUsername(login.getUsername());
            builder.password(new BCryptPasswordEncoder().encode(login.getPassword()) );
            System.out.println("RUOLO:"+user.getRole());
            builder.roles(user.getRole());
            builder.build();
            return "home";
        }
        else
        {
            return "login";
        }
        //request.getSession().setAttribute(user);

    }
}
