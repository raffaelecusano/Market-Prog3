package com.market.Controller;

import org.springframework.stereotype.Controller;

@Controller
public class ClienteController {
/*
    @RequestMapping(value = "/checkNewOffer", method = RequestMethod.POST)
    public @ResponseBody int checkNewOffer(){
        int retValue = getUsr().checkNewOffer();
        return retValue;
    }

 */
/*@RequestMapping(value = "/myOrder", method = RequestMethod.GET)
public String mieiOrdini(Model model){

    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
    String name = auth.getName();
    ArrayList<Integer> ric = getDAO().getRicevutabyUser(name);
    model.addAttribute("ricevute",ric);
    ArrayList<String> nomeProd= new ArrayList<>();
    ArrayList<Integer> qnt = new ArrayList<>();
    for(Integer r : ric){
        HashMap<String,ArrayList> prod= getDAO().getProdByRic(r);
        nomeProd.addAll(prod.get("prod"));
        qnt.addAll(prod.get("qnt"));

    }
    model.addAttribute()

}*/

}
